import 'package:flutter/material.dart';

abstract final class AppColors {
  static const Color primary = Color(0xFF145C4F);
  static const Color canvas = Color(0xFFFAFAF9);
  static const Color surface = Color(0xFFF5F4EF);
  static const Color warmDark = Color(0xFF38564E);
  static const Color terracotta = Color(0xFFC47A5A);
  static const Color sage = Color(0xFFE8F0EB);
  static const Color dustyRose = Color(0xFFF2EAEA);
  static const Color warmIvory = Color(0xFFF5F0E8);
  static const Color blush = Color(0xFFF4EDE8);
  static const Color softBlueGrey = Color(0xFFEAF0F2);

  static const Color text = primary;
  static const Color muted = Color(0xFF6F837D);
  static const Color line = Color(0x1A145C4F);
  static const Color white = Color(0xFFFAFAF9);
  static const Color placeholder = Color(0x996F837D);
  static const Color error = Color(0xFFB85C5C);
  static const Color shadow = Color(0x12000000);
  static const Color forest = primary;
  static const Color success = Color(0xFF88A394);

  static const Color darkBackground = Color(0xFF2B1F1A);
  static const Color darkSurface = Color(0xFF3B2D27);
  static const Color darkText = Color(0xFFF1EDE8);
  static const Color darkPrimary = Color(0xFF5B9B8C);

  static const Color shell = white;
  static const Color card = white;
  static const Color cardStrong = surface;
  static const Color peach = Color(0xFFE7D8CF);
  static const Color gold = Color(0xFFD8B86A);
  static const Color ink = text;
  static const Color premium = terracotta;

  static const LinearGradient backgroundGradient = LinearGradient(
    colors: [canvas, canvas],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );

  static const LinearGradient dawnGradient = backgroundGradient;
  static const LinearGradient premiumGradient = LinearGradient(
    colors: [terracotta, primary],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const LinearGradient calmGradient = LinearGradient(
    colors: [canvas, surface],
    begin: Alignment.topCenter,
    end: Alignment.bottomCenter,
  );

  static const LinearGradient terracottaGlow = LinearGradient(
    colors: [terracotta, Color(0x00FFFFFF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static Color categoryColor(String category) {
    switch (category.trim().toLowerCase()) {
      case 'ground':
        return sage;
      case 'release':
        return dustyRose;
      case 'clarity':
        return warmIvory;
      case 'connect':
        return blush;
      case 'restore':
        return softBlueGrey;
      default:
        return canvas;
    }
  }
}
