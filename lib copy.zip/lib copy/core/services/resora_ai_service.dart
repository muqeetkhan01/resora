import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../../data/models/app_models.dart';

class ResoraAiService {
  ResoraAiService({http.Client? client}) : _client = client ?? http.Client();

  final http.Client _client;

  static const String _apiKey = String.fromEnvironment(
    'OPENAI_API_KEY',
    defaultValue:
        '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',
  );
  static const String _model =
      String.fromEnvironment('OPENAI_MODEL', defaultValue: 'gpt-4.1-mini');

  bool get isConfigured => _apiKey.trim().isNotEmpty;

  Future<String> generateReply({
    required List<ChatMessageModel> messages,
    required String userName,
  }) async {
    if (!isConfigured) {
      throw const _AiConfigException(
        'Talk to Resora is not configured yet.',
      );
    }

    final trimmedMessages =
        messages.where((message) => message.text.trim().isNotEmpty).toList();
    final contextWindow = trimmedMessages.length > 14
        ? trimmedMessages.sublist(trimmedMessages.length - 14)
        : trimmedMessages;

    final input = <Map<String, dynamic>>[
      {
        'role': 'system',
        'content': [
          {
            'type': 'input_text',
            'text': _systemPrompt(userName),
          },
        ],
      },
      ...contextWindow.map(_toInputMessage),
    ];

    final payload = {
      'model': _model,
      'input': input,
      'temperature': 0.6,
      'max_output_tokens': 260,
    };

    final response = await _client
        .post(
          Uri.https('api.openai.com', '/v1/responses'),
          headers: {
            'Authorization': 'Bearer $_apiKey',
            'Content-Type': 'application/json',
          },
          body: jsonEncode(payload),
        )
        .timeout(const Duration(seconds: 25));

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw _AiApiException(_extractErrorMessage(response.body));
    }

    final data = jsonDecode(response.body) as Map<String, dynamic>;
    final outputText = _extractOutputText(data);

    if (outputText.isEmpty) {
      throw const _AiApiException(
        'The assistant returned an empty response. Please try again.',
      );
    }

    return outputText;
  }

  Map<String, dynamic> _toInputMessage(ChatMessageModel message) {
    return {
      'role': message.isUser ? 'user' : 'assistant',
      'content': [
        {
          'type': 'input_text',
          'text': message.text,
        },
      ],
    };
  }

  String _extractOutputText(Map<String, dynamic> data) {
    final direct = data['output_text'];
    if (direct is String && direct.trim().isNotEmpty) {
      return direct.trim();
    }

    final output = data['output'];
    if (output is! List) {
      return '';
    }

    final buffer = StringBuffer();
    for (final item in output.whereType<Map<String, dynamic>>()) {
      final content = item['content'];
      if (content is! List) {
        continue;
      }

      for (final part in content.whereType<Map<String, dynamic>>()) {
        final text = part['text'];
        if (text is String && text.trim().isNotEmpty) {
          if (buffer.isNotEmpty) {
            buffer.writeln();
          }
          buffer.write(text.trim());
        }
      }
    }

    return buffer.toString().trim();
  }

  String _extractErrorMessage(String rawBody) {
    try {
      final decoded = jsonDecode(rawBody);
      if (decoded is Map<String, dynamic>) {
        final error = decoded['error'];
        if (error is Map<String, dynamic>) {
          final message = error['message'];
          if (message is String && message.trim().isNotEmpty) {
            return message.trim();
          }
        }
      }
    } catch (_) {
      // Fall through to generic message.
    }

    return 'OpenAI request failed. Please try again in a moment.';
  }

  String _systemPrompt(String userName) {
    final safeName = userName.trim().isEmpty ? 'friend' : userName.trim();

    return '''
You are Resora, a calm, non-judgmental support guide inside a mental wellness app.

Identity and tone:
- Address the user naturally as "$safeName" only when it feels helpful.
- Be warm, steady, grounded, and practical.
- Keep replies concise: 3-6 short sentences, under 120 words.
- No fluff, no long lists, no generic motivational speech.

Core behavior:
- First, validate the feeling in one sentence.
- Then offer one clear next step the user can take now.
- Optionally suggest ONE app-native support path if relevant:
  Journal, Gentle Reset, Quiet the Noise, Rehearse the Moment, Is This Normal.
- Prefer clear language and short concrete wording.

Safety and boundaries:
- Do not diagnose or provide medical/legal/financial advice.
- If the user mentions self-harm, suicide, harming others, or immediate danger:
  respond with empathy, urge contacting local emergency services immediately,
  and encourage reaching a trusted person right now.
- If uncertain about facts, do not fabricate.

Output style:
- Plain text only, no markdown bullets unless absolutely needed.
- End with a grounded, actionable close.
''';
  }
}

class _AiConfigException implements Exception {
  const _AiConfigException(this.message);

  final String message;

  @override
  String toString() => message;
}

class _AiApiException implements Exception {
  const _AiApiException(this.message);

  final String message;

  @override
  String toString() => message;
}
