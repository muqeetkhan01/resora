import 'package:flutter/widgets.dart';
import 'package:get/get.dart';

import '../../../core/controllers/app_session_controller.dart';
import '../../../core/services/resora_ai_service.dart';
import '../../../data/models/app_models.dart';

class ChatController extends GetxController {
  ChatController({ResoraAiService? aiService})
      : _aiService = aiService ?? ResoraAiService();

  final ResoraAiService _aiService;
  final _session = Get.find<AppSessionController>();

  final inputController = TextEditingController();
  final scrollController = ScrollController();
  final messages = <ChatMessageModel>[].obs;
  final isTyping = false.obs;
  final draftText = ''.obs;

  int _pendingReplies = 0;

  bool get canSend => draftText.value.trim().isNotEmpty;

  @override
  void onInit() {
    super.onInit();
    inputController.addListener(_handleDraftChanged);
  }

  Future<void> sendMessage([String? preset]) async {
    final text = (preset ?? inputController.text).trim();
    if (text.isEmpty) return;

    messages.add(ChatMessageModel(text: text, isUser: true, time: 'Now'));
    inputController.clear();
    _pendingReplies += 1;
    isTyping.value = true;
    _scrollToBottom();

    try {
      final reply = await _aiService.generateReply(
        messages: messages.toList(),
        userName: _session.displayName,
      );
      messages.add(
        ChatMessageModel(
          text: reply,
          isUser: false,
          time: 'Now',
        ),
      );
    } catch (error) {
      messages.add(
        ChatMessageModel(
          text: _friendlyError(error),
          isUser: false,
          time: 'Now',
        ),
      );
    } finally {
      _pendingReplies = (_pendingReplies - 1).clamp(0, 999);
      isTyping.value = _pendingReplies > 0;
      _scrollToBottom();
    }
  }

  void _handleDraftChanged() {
    draftText.value = inputController.text;
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!scrollController.hasClients) return;
      scrollController.animateTo(
        scrollController.position.maxScrollExtent,
        duration: const Duration(milliseconds: 220),
        curve: Curves.easeOut,
      );
    });
  }

  String _friendlyError(Object error) {
    final message = error.toString();
    if (message.contains('not configured')) {
      return 'Talk to Resora is almost ready. Add OPENAI_API_KEY with --dart-define, then restart the app.';
    }
    if (message.toLowerCase().contains('timeout')) {
      return 'I could not reach the assistant in time. Try again in a moment.';
    }
    if (message.toLowerCase().contains('openai')) {
      return 'I hit a connection problem with the assistant. Please try again.';
    }
    return 'I could not complete that reply right now. Please try again.';
  }

  @override
  void onClose() {
    inputController.removeListener(_handleDraftChanged);
    inputController.dispose();
    scrollController.dispose();
    super.onClose();
  }
}
